import React from 'react';
import './App.css';
import AllTodos from './AllJokes';
import AddJoke from './AddJoke';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { alljokes: props.jokes.getjokes() };
  }
  saveJoke = (joke) => {
    this.props.jokes.addJoke(joke);
    this.setState({ alljokes: this.props.jokes.getjokes() });
  }
  render() {
    return (
      <div className="container row">
      <p>Random Todo: <span>{this.props.jokes.getRandomJoke()}</span></p>
      <div className="col1">
      <p className="head">Add Todo</p>
      <AddJoke saveJoke={this.saveJoke} />
    </div>
      <div className="col2">
      <p className="head">All Todo's</p>
      <AllTodos jokes={this.state.alljokes} />
    </div>
      </div>
    )
  };
}

export default App;
