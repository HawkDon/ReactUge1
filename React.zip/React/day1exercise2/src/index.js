import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//import App from './App';
import registerServiceWorker from './registerServiceWorker';
import App from './App2';
import Clock from './Clock';
import Toggle from './Toggle';

// ReactDOM.render(<App name='Oliver'/>, document.getElementById('root'));
registerServiceWorker();
ReactDOM.render(<App />, document.getElementById('root'))
ReactDOM.render(<Clock txt='Now i can pass what i want into Clock!' />, document.getElementById('root2'))
ReactDOM.render(<Toggle />, document.getElementById('root3'))