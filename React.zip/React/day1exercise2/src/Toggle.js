import React from 'react';

class Toggle extends React.Component {
    constructor(props) {
      super(props);
      this.state = {isToggleOn: true};
  
      // This binding is necessary to make `this` work in the callback
      // this.handleClick = this.handleClick.bind(this);
    }
  
    handleClick = () => {
      this.setState(prevState => ({
        isToggleOn: !prevState.isToggleOn
      }));
    }
  
    render() {
      return (
        <button onClick={this.handleClick}>
          {this.state.isToggleOn ? 'ON' : 'OFF'}
        </button>
      );
    }
  }

  export default Toggle;

  // What is the purpose of this line in the constructor: this.handleClick = this.handleClick.bind(this);
  // You change the value from true and false whenever you click on the button.

  // How can we disable the default behavior of an event handler (for example prevent a submit handler to submit?)
  // Not include it in the constructor i believe.

  // What is the benefit(s) you get from using arrow-functions in a ES6 class?
  //Less code you have to work with, and less chances of getting bugs