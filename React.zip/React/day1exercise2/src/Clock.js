import React from 'react';

class Clock extends React.Component {
    //The constructor for a React component is called before it is mounted.
    //When implementing the constructor for a React.Component subclass, you should call super(props) before any other statement.
    //Otherwise, this.props will be undefined in the constructor, which can lead to bugs.
    constructor(props) {
      super(props);
      this.state = {date: new Date()};
      console.log("I am the constructor")
    }

    //Called immediately after a component is mounted
    componentDidMount() {
        this.timerID = setInterval(
            () => this.tick(),
            10000
          );
          console.log("I am the componentDidMount")
    }
  
    //Called immediately before component is destroyed
    componentWillUnmount() {
        clearInterval(this.timerID);
        console.log("I am the componentWillUnmount")
    }

    //Called immediatlly after the DOM has been updated
    componentDidUpdate(prevProps, prevState){
        console.log("I am the componentDidUpdate")
    }

    //Called immediately before mounting occurs
    //componentWillMount(){
    //    console.log("I am the componentWillMount")
    //}

    tick() {
        this.setState({
          date: new Date()
        });
        console.log("I am the tick")
      }
    //Renders the DOM node and updates
    render() {
        console.log("I am the render")
      return (
        <div>
          <h1>{this.props.txt}</h1>
          <h2>It is {this.state.date.toLocaleTimeString()}.</h2>
        </div>
      );
    }
  }

  export default Clock;

  //Would it be possible to rework the class component into a functional function?
  //No it is not possible because State only works for the class component

  //How do you set new values for state: In the constructor, and all other places?
  //In the constructor and in the render() method

  //How is it possible to "tell" React that you want the UI to be updated (re-rendered)?
  //By setting an interval so it updated frequently when you decide it.
  
  //What is the differences between props and state
  //Props is data that talks with the component. It is what makes the communication between function
  //and the dom. Props pass data from the nodes and are immutable, so if we already have a package of data
  //we want to pass, props are the way to go, but what if we want to pass data straight into the component
  //from the user input data? this is where State comes in.
  //State is an object that determines how that component renders & behaves. In other words state is what
  //allows you to create components that are dynamic and interactive.

 /* props cons:
 * are immutable, which lets React do fast reference checks
 * are used to pass data down from your view-controller, your top level component
 * have better performance, use this to pass data to child components
    state cons:
 * should be managed in your view-controller, your top level component
 * is mutable, has worse performance
 * should not be accessed from child components, pass it down with props instead
  */

  //What is the purpose of React Components Life Cycle Methods?
  //To make a component more dynamic and interactive