import React, { Component } from 'react';
import './App.css';

// What is a class component?
// This is a class component and has the same function as a functional component plus state properties
/*class App extends Component {
  render() {
    return (
      <div className="App">
        <header>
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <p className="App-intro">
        <h1>Hello {this.props.name} !</h1>
        </p>
      </div>
    );
  }
} */
// What is a functional component?
// This is a functional component and has the same function as a class component minus state properties.
function App(props) {
  return <div className="App">
  <header>
    <h1 className="App-title">Welcome to React</h1>
  </header>
  <p className="App-intro">
  <h1>Hello {props.name} !</h1>
  </p>
</div>
}

// What is a the idea of props?
// Props stands for properties arguments for an object and returns a react element.
// So a component only reads the properties and return a element on the DOM.

// A quick example of a component that accepts a prop
/*function ExampleReact(props) {
  return <h1>Hello i am a function that returns properties from: {props}</h1>
}*/

//Example of a component that returns object property data
/*const person = {
  first: 'Wes',
  last: 'Bos',
  country: 'Canada',
  city: 'Hamilton',
  twitter: '@wesbos'
};
const {first, last} = person;
function ExampleReacts() {
  return <h1>Hello now i return firstname data: {first} and lastname data: {last}</h1>
} */
export default App;
