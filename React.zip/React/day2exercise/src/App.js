import React, { Component } from 'react';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <header>
          <h1 className="App-title">Welcome to React Day 2</h1>
        </header>
      </div>
    );
  }
}

export default App;
