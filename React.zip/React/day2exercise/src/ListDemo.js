import React from 'react';
import {cars} from './carsStore';

function ListItem(props) {
    return <li>{props.value}</li>;
  }
  
  function NumberList(props) {
    const numbers = props.numbers;
    const listItems = numbers.map((number) =>
      <ListItem key={number.toString()}
                value={number} />
  
    );
    return (
      <ul>
        {listItems}
      </ul>
    );
  }

  function ListItemsInTable(props) {
      return <tr><td>{props.value}</td></tr>;
  }

  function NumberTable(props) {
    const numbers = props.numbers;
    const listItems = numbers.map((number) =>
    <ListItemsInTable key={number.toString()}
                value={number}/>
    );
return (
    <table>
        <tbody>
        <tr>
            <th>NumberTable</th>
        </tr>
        {listItems}
        </tbody>
    </table>
);
}

function ListCarsInTable(props) {
    return <tr><td>{props.value.id}</td><td>{props.value.year}</td><td>{props.value.make}</td><td>{props.value.model}</td><td>{props.value.price}</td></tr>
}

function CarsTable(props) {
    const cars = props.allCars;
    const listOfCars = cars.map((car) => 
    <ListCarsInTable key={car.year.toString()}
    value={car}/>
);
return (
    <table>
    <tbody>
    <tr>
        <th>ID</th>
        <th>Year</th>
        <th>Make</th>
        <th>Model</th>
        <th>Price</th>
    </tr>
    {listOfCars}
    </tbody>
</table>
)
}

class ListDemo extends React.Component {
    constructor() {
        super();
        this.state = {
            number: [6, 7, 8, 9, 10],
            allCars: cars
        }
    }
    render(){
        return (
            <div >
                <h2>NumberList</h2>
                <h2><NumberList numbers={[1,2,3,4,5]}/></h2>
                <h2>StateList</h2>
                <h2><ul>{this.state.number.map(number => <li key={number}>{number}</li>) }</ul></h2>
                <h2><NumberTable numbers={[11,12,13,14,15]}/></h2>
                <h2><CarsTable allCars={this.state.allCars}/></h2>

            </div>
        )
    }
}

export default ListDemo;


//What is the purpose of the key value, which must be given to individual rows in a react-list
//To give each value on the DOM an unique primary key, so we later can find and operate on the same data

//It's recommended to use a unique value from you data if available (like an ID). How do you get a unique value in a map callback, for data without a unique id?
//U can define whatever you like for the key. It doesn't have to be the ID, but is recommended in most cases.

//Where is the only place you can set state directly as in: this.state = {name: "Peter"};
//In the constructor.

//How must you set state all other places?
//By using setState.