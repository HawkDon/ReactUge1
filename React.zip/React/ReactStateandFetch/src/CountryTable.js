import React, { Component } from "react";

class CountryTable extends Component {

  handleLength = (props) => {
    if(props === 1) {
      return "";
    } else {
      return "(+" + props + ")"
    }
  }
  render() {
    const listOfCountries = this.props.countries.map((country) => <tr key={country.population}><td>{country.name}</td><td>{country.capital}</td><td>{country.region}</td><td>{country.population}</td><td>{country.area}</td><td>{country.timezones[0]}{this.handleLength(country.timezones.length)}</td><td>{country.borders[0]}{this.handleLength(country.borders.length)}</td><td>{country.topLevelDomain[0]}{this.handleLength(country.topLevelDomain.length)}</td><td>{country.currencies[0]}{this.handleLength(country.currencies.length)}</td><td>{country.languages[0]}{this.handleLength(country.languages.length)}</td></tr>
  )
    const labels = this.props.labels
    const listOfLabels = <tr><th>{labels[0]}</th><th>{labels[1]}</th><th>{labels[2]}</th><th>{labels[3]}</th><th>{labels[4]}</th><th>{labels[5]}</th><th>{labels[6]}</th><th>{labels[7]}</th><th>{labels[8]}</th><th>{labels[9]}</th></tr>
    return (
      <table className="table">
        <thead>
          {listOfLabels}
        </thead>
        
        <tbody>
        {listOfCountries}
        </tbody>
      </table>
    );
  }
}
export default CountryTable;