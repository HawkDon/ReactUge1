//Add imports here
const labels = "http://localhost:3333/labels"
const countries = "http://localhost:3333/countries"

class CountryFactory {
  
   getLabels = async () => {
     const data = await fetch(labels).then(Response => Response.json())
     return data;
   }
   
   getCountries = async () => {
     const data = await fetch(countries).then(Response => Response.json())
     return data;
   }
}

export default new CountryFactory();