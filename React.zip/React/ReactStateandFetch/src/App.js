import React from 'react';
import CountryTable from "./CountryTable";
import './App.css';

class App extends React.Component {
  
  constructor(){
    super();
    this.state = ({
      countries: [],
      labels: [],
      timer: 0
    })
  }

  NumberOfGuiUpdates = () => {
    var number = this.state.timer+1;
    this.setState({timer:number})
  }

  async componentDidMount() {
    this.timerID = setInterval(
      () => this.tick(),
      3000
    );
  }

  async tick() {
    const labels = await this.props.factory.getLabels();
    const countries = await this.props.factory.getCountries();
    this.setState({
      countries: countries,
      labels: labels,
      timer: this.state.timer+1
    })
    this.NumberOfGuiUpdates
  }

  render() {
    return (
      <div>
        <div className="App-header">
          <h2>React, State, Fetch and Mobx</h2>
        </div>
        Number of updates: {this.state.timer}
        <div className="App-intro">      
          <CountryTable countries={this.state.countries} labels={this.state.labels}/>
        </div>
      </div>
    );
  }
}

export default App;
