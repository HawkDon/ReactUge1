import React from 'react';
import './App.css';
import AllPersons from './AllPersons';
import AddPerson from './AddPerson';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      personLength: props.personStore.persons.length,
      allPersons: props.personStore.getPersons()
    }
  }
  addPerson = (person) => {
    this.props.personStore.addPerson(person);
    this.setState({
      personLength: this.props.personStore.persons.length,
      allPersons: this.props.personStore.getPersons()})
  }
  render() {
    return (
      <div>
      <h1>State lift demo</h1>
      <h1>All persons</h1>
      <h2>Total Persons: {this.state.personLength}</h2>
      <AllPersons persons={this.state.allPersons}/>
      <AddPerson savePerson={this.addPerson}/>
      </div>
    );
  }
}

export default App;
