import React from 'react';

class AllPersons extends React.Component {
    
    render(){
        const list = this.props.persons.map(person => <tr><td>{person.firstName}</td><td>{person.lastName}</td><td>{person.email}</td></tr>)
        return (
            <table>
            <tbody>
            <tr>
            <th>FirstName</th>
            <th>LastName</th>
            <th>Email</th>
            </tr>
            {list}
            </tbody>
            </table>
        )
    }
}

export default AllPersons;