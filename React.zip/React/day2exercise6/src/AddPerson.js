import React from 'react';

class AddPerson extends React.Component {
    constructor() {
        super();
        this.state = {
            person: {
                firstName: "",
                lastName: "",
                email: "",
            }
        }
    }

    handleInput = (event) => {
        const target = event.target;
        const prop = target.id;
        var value = target.value;
        var person = this.state.person;
        person[prop] = value;
        this.setState({
            person: person
        })
    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.props.savePerson(this.state.person);
    }

render(){
    return (
        <div>
        <form onSubmit={this.handleSubmit}>
        FirstName:
        <input id="firstName" value={this.state.person.firstName} onChange={this.handleInput} />
        LastName:
        <input id="lastName" value={this.state.person.lastName} onChange={this.handleInput} />
        Email:
        <input id="email" value={this.state.person.email} onChange={this.handleInput} />
        <button>Save</button>
        </form>
        </div>
    )
}
}

export default AddPerson;