class PersonStore {
    constructor() {
        this.persons = [
            {
                firstName: 'Oliver',
                lastName: 'Loenning',
                email: 'Oliver@Mail.dk'
            },
            {
                firstName: 'Kasper',
                lastName: 'Jensen',
                email: 'Kasper@Mail.dk' 
            }
        ]
    }
    addPerson(person) {
        this.persons.push(person);
    }
    getPersons() {
        return this.persons;
    }
}

export default new PersonStore();