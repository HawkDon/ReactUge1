import React from 'react';
import '../styles/App.css';
import AddEditPerson from "./AddEditPerson"
import AllPersons from "./AllPersons"

class App extends React.Component {

  constructor(props) {
    super(props);
    this.state= {persons: [],
    personToEdit: ""}
  }

  async componentDidMount() {
    //This would be the perfect place to fetch persons from the API
    let data = await this.props.DataFacade.getPersons();
    this.setState({
      persons: data
    })
  }

  deletePerson = async (id) => {
    await this.props.DataFacade.deletePerson(id);
    let data = await this.props.DataFacade.getPersons();
    this.setState({
      persons: data
    })
  }

  editPerson = (id) => {
    this.setState({
      personToEdit: id
    })
  }

  putPerson = async (person) => {
    const id = this.state.personToEdit
    await this.props.DataFacade.putPerson(id, person);
    let data = await this.props.DataFacade.getPersons();
    this.setState({ persons: data})
  }

  savePerson = async (person) => {
    await this.props.DataFacade.addPerson(person);
    let data = await this.props.DataFacade.getPersons();
    this.setState({ persons: data });
  }



  render() {
    return (
      <div style={{ margin: 30, width: "90%" }}>
        <h3>CRUD Demo </h3>
        <div className="row">
          <div className="col-md-6">
            <h3>All Persons</h3>
            <AllPersons putPerson={this.editPerson} persons={this.state.persons} deletePerson={this.deletePerson} />
          </div>
          <div className="col-md-6" >
            <h3 style={{textAlign:"center"}}>Add Person</h3>
            <AddEditPerson putPerson={this.putPerson} editPerson={this.state.personToEdit} addPerson={this.savePerson}/>
          </div>
        </div>

      </div>
    );
  }
}

export default App;
