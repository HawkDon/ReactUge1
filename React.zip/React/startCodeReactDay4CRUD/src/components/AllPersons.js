import React from "react"

export default class AllPersons extends React.Component {
  
  onEdit = (event) => {
    let id = event.target.id;
    this.props.putPerson(id);
  }

  onDelete = (event) => {
    let id = event.target.id;
    this.props.deletePerson(id);
  }

  render() {
    const persons = this.props.persons;
    const listOfPersons = persons.map((person) => <tr key={person.id}><td>{person.age}</td><td>{person.name}</td><td>{person.gender}</td><td>{person.email} <a onClick={this.onEdit} id={person.id}>(Edit)</a><a onClick={this.onDelete} id={person.id}>(Delete)</a></td></tr>
  )

    return (
      <div>
      <table className="table">
      <thead>
        <tr><th>Age</th><th>Name</th><th>Gender</th><th>Email</th></tr>
      </thead>
      <tbody>
        {listOfPersons}
      </tbody>
    </table>
      </div>
    )
  }
}