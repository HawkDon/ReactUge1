const URL = "http://localhost:3456/api";


// Simple way to handle HTTP-errors which otherwise does not throw an exception with the fetch-API
/*function handleHttpErrors(res) {
  if (!res.ok) {
    throw Error(res.statusText);
  }
  return res.json();
} */

function makeOptions(type, data) {
  return {
    method: type,
    body: JSON.stringify(data),
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    }
  }
}
class DataFacade {

  async deletePerson(id) {
   await fetch(URL + "/" + id, makeOptions("DELETE"))
 }

  async putPerson(id, person) {
    await fetch(URL + "/" + id, makeOptions("PUT", person));
  }

  async getPersons() {
    return await fetch(URL).then(Response => Response.json());
  }

  async addPerson(person) {
    await fetch(URL, makeOptions("POST", person))
  }
}


export default new DataFacade();